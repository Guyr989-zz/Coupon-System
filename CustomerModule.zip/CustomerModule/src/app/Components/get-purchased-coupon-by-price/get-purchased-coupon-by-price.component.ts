import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-purchased-coupon-by-price',
  templateUrl: './get-purchased-coupon-by-price.component.html',
  styleUrls: ['./get-purchased-coupon-by-price.component.css']
})
export class GetPurchasedCouponByPriceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
